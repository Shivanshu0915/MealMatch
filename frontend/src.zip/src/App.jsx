import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
  Outlet,
} from "react-router-dom";

import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from "./context/ProtectedRoute";
import RedirectHandler from "./context/RedirectHandler";

// Auth and common page
import HomePage from "./pages/public/HomePage";
import Login from "./pages/auth/Login";
import Signup from "./pages/auth/Signup";
import OTPPage from "./pages/auth/OTP";

// Layouts
import SeekerLayout from "./layouts/SeekerLayout";
import ProviderLayout from "./layouts/ProviderLayout";

// Provider pages
import ProviderDashboard from "./pages/provider/Dashboard/ProviderDashboard";
import PostFood from "./pages/provider/PostFood/PostFood";
// import FindSeeker from "./pages/provider/FindSeeker/FindSeeker";
import ProviderRequests from "./pages/provider/Requests/ProviderRequests";

// Seeker pages
import SeekerDashboard from "./pages/seeker/Dashboard/SeekerDashboard";
import SeekerRequests from "./pages/seeker/Requests/SeekerRequests";
import SeekerActivePickups from "./pages/seeker/Active Pickups/SeekerActivePickups";

// shared
import Activity from "./pages/activity/Activity/Activity";
import History from "./pages/history/History";
import Profile from "./pages/profile/Profile";
import Settings from "./pages/settings/Settings";
import SeekerFindFood from "./pages/seeker/FindFood/SeekerFindFood";

const App = createBrowserRouter(
  createRoutesFromElements(
    <>
      <Route element={<AuthProvider><Outlet /></AuthProvider>}>
      {/* Public Routes */}
        <Route path="/" element={<RedirectHandler><HomePage/></RedirectHandler>} />
        <Route path="/login" element={<RedirectHandler><Login/></RedirectHandler>} />
        <Route path="/signup" element={<RedirectHandler><Signup/></RedirectHandler>} />
        <Route path="/otpverify" element={<RedirectHandler><OTPPage/></RedirectHandler>} />

        {/* Protected Provider only Routes */}
        <Route element={<ProtectedRoute allowedRole="provider" />}>
          <Route path="/providerDashboard" element={<ProviderLayout/>}>
            <Route index element={<ProviderDashboard />} />
            <Route path="post-food" element={<PostFood />} />
            {/* <Route path="find-seeker" element={<FindSeeker />} /> */}
            <Route path="requests" element={<ProviderRequests />} />
            <Route path="activity" element={<Activity />} />
            <Route path="history" element={<History />} />
            <Route path="profile" element={<Profile />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Route>
        
        {/* Protected Seeker only routes */}
        <Route element={<ProtectedRoute allowedRole="seeker"/>}> 
          <Route path="/seekerDashboard" element={<SeekerLayout />}>
            <Route index element={<SeekerDashboard />} />
            <Route path="find-food" element={<SeekerFindFood />} />
            <Route path="requests" element={<SeekerRequests />} />
            <Route path="active-pickups" element={<SeekerActivePickups />} />
            <Route path="activity" element={<Activity />} />
            <Route path="history" element={<History />} />
            <Route path="profile" element={<Profile />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Route>

      </Route>
    </>
  )
);

export default App;
