export const ITEMS_PER_PAGE = 5;
export const MAX_ITEMS = 30;
