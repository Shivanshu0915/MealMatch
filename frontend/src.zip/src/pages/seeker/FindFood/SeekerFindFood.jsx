import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  MapPin,
  Navigation,
  Leaf,
  Drumstick,
  Star,
  Shield,
  Plus,
  Minus,
  ZoomIn,
  ZoomOut,
  Layers,
  Timer,
  Utensils,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  mockAvailableFood,
  getSeekerTimeRemaining,
} from '@/data/seekerMockData';

const SeekerFindFood = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [radius, setRadius] = useState(5);
  const [useGPS, setUseGPS] = useState(false);
  const [selectedFood, setSelectedFood] = useState(null);
  const [requestQuantity, setRequestQuantity] = useState(10);
  const [requestNote, setRequestNote] = useState('');
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [mapboxToken, setMapboxToken] = useState('');

  const filteredFood = useMemo(() => {
    return mockAvailableFood.filter((food) => {
      const matchesSearch =
        food.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        food.provider.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRadius = food.provider.distance <= radius;
      return matchesSearch && matchesRadius;
    });
  }, [searchQuery, radius]);

  const handleGetLocation = () => {
    if (!navigator.geolocation) return;

    navigator.geolocation.getCurrentPosition(
      () => {
        setUseGPS(true);
        toast.success('Location updated');
      },
      () => {
        toast.error('Unable to get location');
      }
    );
  };

  const handleFoodClick = (food) => {
    setSelectedFood(food);
    setRequestQuantity(Math.min(10, food.quantity));
  };

  const handleSubmitRequest = () => {
    setShowConfirmDialog(false);
    setSelectedFood(null);
    setRequestNote('');

    toast.success('Request sent successfully!', {
      description: `Your request for ${requestQuantity} ${selectedFood?.quantityUnit} has been sent to ${selectedFood?.provider.name}`,
    });
  };

  const getFoodTypeIcon = (type) => {
    switch (type) {
      case 'veg':
        return <Leaf className="w-4 h-4 text-success" />;
      case 'non-veg':
        return <Drumstick className="w-4 h-4 text-destructive" />;
      default:
        return <Utensils className="w-4 h-4 text-warning" />;
    }
  };

  const getFreshnessBadge = (freshness) => {
    switch (freshness) {
      case 'fresh':
        return <Badge variant="success">Fresh</Badge>;
      case 'good':
        return <Badge variant="info">Good</Badge>;
      default:
        return <Badge variant="warning">Use Soon</Badge>;
    }
  };

  return (
    <>
      <div className="flex flex-col w-full h-full">
        {/* Top Controls */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 border-b bg-card"
        >
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex flex-1 gap-2">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search area or food..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <Button
                variant={useGPS ? 'default' : 'outline'}
                onClick={handleGetLocation}
                className="shrink-0"
              >
                <Navigation className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">
                  {useGPS ? 'GPS Active' : 'Get Location'}
                </span>
              </Button>
            </div>

            <div className="flex items-center gap-4 min-w-[280px]">
              <span className="text-sm text-muted-foreground">Radius:</span>
              <Slider
                value={[radius]}
                onValueChange={(v) => setRadius(v[0])}
                min={1}
                max={15}
                step={1}
                className="flex-1"
              />
              <span className="text-sm font-medium text-info w-12">
                {radius} km
              </span>
              <Badge variant="info">{filteredFood.length} posts</Badge>
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
          {/* Map Section */}
          <div className="flex-1 relative min-h-[300px] lg:min-h-0">
            {!mapboxToken ? (
              <div className="absolute inset-0 flex items-center justify-center bg-muted/50">
                <Card className="w-full max-w-md mx-4">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-info" />
                      Map Configuration
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      Enter your Mapbox public token to enable the interactive
                      map.
                    </p>
                    <Input
                      placeholder="pk.eyJ1..."
                      value={mapboxToken}
                      onChange={(e) => setMapboxToken(e.target.value)}
                    />
                    <Button className="w-full" disabled={!mapboxToken}>
                      Enable Map
                    </Button>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <div className="absolute inset-0 bg-muted/30 flex items-center justify-center">
                <p className="text-muted-foreground">
                  Interactive map will appear here
                </p>
              </div>
            )}

            <div className="absolute top-4 right-4 flex flex-col gap-2">
              <Button variant="secondary" size="icon">
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button variant="secondary" size="icon">
                <ZoomOut className="w-4 h-4" />
              </Button>
              <Button variant="secondary" size="icon">
                <Layers className="w-4 h-4" />
              </Button>
            </div>

            {useGPS && (
              <div className="absolute bottom-4 left-4">
                <Badge variant="info">
                  <Navigation className="w-3 h-3 mr-1" />
                  GPS Active
                </Badge>
              </div>
            )}
          </div>

          {/* Food List */}
          <div className="w-full lg:w-80 xl:w-96 border-t lg:border-t-0 lg:border-l bg-card overflow-y-auto">
            <div className="p-4 space-y-3">
              <h3 className="font-semibold">Nearby Food</h3>

              {filteredFood.map((food) => (
                <motion.div
                  key={food.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  whileHover={{ scale: 1.02 }}
                  className="cursor-pointer"
                  onClick={() => handleFoodClick(food)}
                >
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex gap-3">
                        <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-muted">
                          {getFoodTypeIcon(food.foodType)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium truncate">
                            {food.title}
                          </h4>
                          <p className="text-sm text-muted-foreground truncate">
                            {food.provider.name}
                          </p>
                          <div className="flex gap-3 mt-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              {food.provider.distance} km
                            </span>
                            <span className="flex items-center gap-1">
                              <Timer className="w-3 h-3" />
                              {getSeekerTimeRemaining(food.bestBefore)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Modals (unchanged logic) */}
        <AnimatePresence>
          {selectedFood && !showConfirmDialog && (
            <Dialog
              open={!!selectedFood}
              onOpenChange={() => setSelectedFood(null)}
            >
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    {getFoodTypeIcon(selectedFood.foodType)}
                    {selectedFood.title}
                  </DialogTitle>
                  <DialogDescription>
                    from {selectedFood.provider.name}
                  </DialogDescription>
                </DialogHeader>

                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => setSelectedFood(null)}
                  >
                    Cancel
                  </Button>
                  <Button onClick={() => setShowConfirmDialog(true)}>
                    Request Food
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </AnimatePresence>

        <Dialog
          open={showConfirmDialog}
          onOpenChange={setShowConfirmDialog}
        >
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Request</DialogTitle>
              <DialogDescription>
                Please review your request before submitting
              </DialogDescription>
            </DialogHeader>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowConfirmDialog(false)}
              >
                Back
              </Button>
              <Button onClick={handleSubmitRequest}>
                Confirm Request
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default SeekerFindFood;
